import pygame as p
import ChessEngine, SmartMoveFinder

p.display.set_caption('Comp Sci Chess')
width = height = 512
dimension = 8 #8x8 board
s_size = height // dimension
max_fps = 15
images = {}

# File reader, Ivan
data = open("PartyGames/data", "r")
# Read from file
datacontent = data.readlines()
# PlayerOne is equal to first line
playerOne = datacontent[0].strip()
# PlayerTwo is equal to second line
playerTwo = datacontent[1].strip()
# Close file reader
print(playerOne)
print(playerTwo)
data.close()

playerOne == "True"
playerTwo == "True"

def loadImages():
    pieces = ['wp', 'wR', 'wN', 'wB', 'wK', 'wQ', 'bp', 'bR', 'bN', 'bB', 'bK', 'bQ']
    for piece in pieces:
        images[piece] = p.transform.scale(p.image.load("PartyGames/" + piece + ".png"), (s_size,s_size))

def main():
    p.init()
    screen = p.display.set_mode((width,height))
    clock = p.time.Clock()
    screen.fill(p.Color("white"))
    gs = ChessEngine.GameState()
    validMoves = gs.getValidMoves()
    moveMade = False #flag variable for when a move is made
    animate = False #flag variable for aniamted moves
    loadImages()
    running = True
    s_selected = () #no square selected, keeps track of the last click of the user (stored as a tuple (row,column))
    p_clicks = [] #keeps track of player clicks (contains two tuples,where it was and where it is moving to)
    gameOver = False
    while running:
        humanTurn = (gs.whiteToMove and playerOne == "True") or (not gs.whiteToMove and playerTwo == "True")
        for e in p.event.get():
            if e.type == p.QUIT:
                running = False
            #mouse handler
            elif e.type == p.MOUSEBUTTONDOWN:
                if not gameOver and humanTurn:
                    location = p.mouse.get_pos() #x and y position of mouse
                    col = location[0]//s_size
                    row = location[1]//s_size
                    if s_selected == (row, col): #the user clicks the same square
                        s_selected = () #unselect
                        p_clicks = [] #clears player clicks
                    
                    else:
                        s_selected = (row, col)
                        p_clicks.append(s_selected) #append for both 1st and 2nd clicks
                    if len(p_clicks) == 2: #after 2nd click
                        move = ChessEngine.Move(p_clicks[0], p_clicks[1], gs.board)
                        print(move.getChessNotation())
                        for i in range(len(validMoves)):
                            if move == validMoves[i]:
                                gs.makeMove(validMoves[i])
                                moveMade = True
                                animate = True
                                s_selected = () #reset user clicks
                                p_clicks = [] #resets player clicks
                        if not moveMade:
                            p_clicks = [s_selected]
            #key handlers
            elif e.type == p.KEYDOWN:
                if e.key == p.K_z: #undo the move if 'z' is pressed
                    gs.undoMove()
                    moveMade = True
                    animate = False
                if e.key == p.K_x: #reset game if r button is clicked
                    gs = ChessEngine.GameState()
                    validMoves = gs.getValidMoves()
                    s_selected = ()
                    p_clicks = []
                    moveMade = False
                    animate = False
                    gameOver = False

        #AI move finder logic
        if not gameOver and not humanTurn:
            AIMove = SmartMoveFinder.findBestMove(gs, validMoves)
            if AIMove is None:
                AIMove = SmartMoveFinder.findRandomMove(validMoves)
            gs.makeMove(AIMove)
            moveMade = True
            animate = True
                    

        if moveMade:
            if animate:
                animatedMove(gs.moveLog[-1], screen, gs.board, clock)
            validMoves = gs.getValidMoves()
            moveMade = False
            animate = False

        drawGameState(screen, gs, validMoves, s_selected)

        if gs.checkMate:
            gameOver = True
            if gs.whiteToMove:
                drawText(screen, 'Black wins by checkmate')
            else:
                drawText(screen, 'White wins by checkmate')
        elif gs.staleMate:
            gameOver = True
            drawText(screen, 'Stalemate')

        clock.tick(max_fps)
        p.display.flip()

#highlight the square selected and possible moves for selected pieces
def highlightSquares(screen, gs, validMoves, s_selected):
    if s_selected != ():
        r, c = s_selected
        if gs.board[r][c][0] == ('w' if gs.whiteToMove else 'b'): #square selected is a piece that can be moved
            #highlight selected square
            s = p.Surface((s_size,s_size))
            s.set_alpha(100)#transparancy value
            s.fill(p.Color('blue'))
            screen.blit(s, (c*s_size, r*s_size))
            #highlight moves from that square
            s.fill(p.Color('yellow'))
            for move in validMoves:
                if move.startRow == r and move.startCol == c:
                    screen.blit(s, (move.endCol*s_size, move.endRow*s_size))



def drawGameState(screen, gs, validMoves, s_selected):
    drawBoard(screen) #draw squares on the board
    highlightSquares(screen, gs, validMoves, s_selected)
    drawPieces(screen, gs.board) #draw pieces on the board


def drawBoard(screen):
    global colours
    colours = [p.Color("gray"), p.Color("red")]
    for r in range(dimension):
        for c in range (dimension):
            color = colours[((r+c) % 2)]
            p.draw.rect(screen, color, p.Rect(c*s_size, r*s_size, s_size, s_size))

def drawPieces(screen, board):
    for r in range (dimension):
        for c in range (dimension):
            piece = board[r][c]
            if piece != "--": #if not an empty square
                screen.blit(images[piece], p.Rect(c*s_size, r*s_size, s_size,s_size))

#Animating moves
def animatedMove(move, screen, board, clock):
    global colours
    dR = move.endRow - move.startRow
    dC = move.endCol - move.startCol
    framesPerSquare = 10 #frames moved one square
    frameCount = (abs(dR) + abs(dC)) * framesPerSquare
    for frame in range(frameCount + 1):
        r, c = ((move.startRow + dR*frame/frameCount, move.startCol + dC*frame/frameCount))
        drawBoard(screen)
        drawPieces(screen, board)
        #erase piece moved from it's ending square
        colour = colours[(move.endRow + move.endCol) % 2]
        endSquare = p.Rect(move.endCol*s_size, move.endRow*s_size, s_size, s_size)
        p.draw.rect(screen, colour, endSquare)
        #draw the captured piece back onto the rectangle
        if move.pieceCaptured != '--':
            screen.blit(images[move.pieceCaptured], endSquare)
        #draw moving piece
        screen.blit(images[move.pieceMoved], p.Rect(c*s_size, r*s_size, s_size, s_size))
        p.display.flip()
        clock.tick(60)


def drawText(screen, text):
    font = p.font.SysFont("Helvitca", 32, True, False)
    textObject = font.render(text, 0, p.Color('Black'))
    textLocation = p.Rect(0, 0, width, height).move(width/2 - textObject.get_width()/2, height/2 - textObject.get_height()/2)
    screen.blit(textObject, textLocation)
    textObject = font.render(text, 0, p.Color("white"))
    screen.blit(textObject, textLocation.move(2,2))


if __name__ == "__main__":
    main()


# https://www.youtube.com/@eddiesharick6649