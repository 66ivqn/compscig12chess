# Name: Ivan Liu
# Date: December 28, 2024
# Program: Main Menu
# Description: To create a program that acts as the main menu to the games in our group project

# Credits
# Main Menu Ivan
# Chess: Connor
# Checkers: Hersh

# Import modules
import pygame  
import sys     
import random  
import math
from ChessMain import main
from Checkers import *

# Initialize all imported pygame modules
pygame.init() 

# Store system resolution
displayinfo = pygame.display.Info() 
# Store system resolution
displayresolution = (displayinfo.current_w, displayinfo.current_h)

# Set base resolution
basewidth = 800
baseheight = 600 

# Make a list of cyclable resolutions
resolutions = [
    (800, 600),  
    (1024, 768), 
    (1280, 720), 
]  

# Check if system resolution is included in previous list, if not add it
if displayresolution not in resolutions:  
    resolutions.append(displayresolution)

# Store index info for resolution
resolutionindex = 0
# Set screen width and height based on resolution selected
screenwidth, screenheight = resolutions[resolutionindex]

# Set a variable that defines which type of window (0 = windows, 1 = fullscreen)
screentype = 0 
# Create display screen
screen = pygame.display.set_mode((screenwidth, screenheight), screentype)  
# Set window title
pygame.display.set_caption("Party Games")

# Set variable for framerate
framerate = pygame.time.Clock()

# Set colours
backgroundcolour = (35, 37, 38)
buttoncolour = (52, 152, 219)
hovercolour = (41, 128, 185)
selectcolour = (255, 215, 0)
textcolour = (255, 255, 255) 

# Set the base font size 
basefont = 32 

# Create menu states
mainmenuscreen = "mainmenu"
playscreen = "play" 
chessscreen = "chess"
checkersscreen = "checkers"
optionsscreen = "options" 
creditsscreen = "credits"
flappybirdscreen = "flappy bird"

# Create variable for current screen and set main menu as start screen
currentscreen = mainmenuscreen
# Store which/if button is highlighted
highlightbuttonid = None

# Toggles for fullscreen and sound mute
fullscreenenabled = False 
soundmuted = False 

# Load the image 
backgroundimg = pygame.image.load("PartyGames/background.PNG").convert()  
# Scale it to the current screen size
backgroundimg = pygame.transform.scale(backgroundimg, (screenwidth, screenheight))
# Make a copy of the background image
backgroundimgcopy = backgroundimg.copy()

# Create a function that adjusts resolution and rescale everything
def setresolution(width, height):

    # Declare global variables
    global screen, screenwidth, screenheight, screentype, backgroundimgcopy
    # Update the global screen dimensions
    screenwidth, screenheight = width, height  
    # Recreate the display with the updated size and type
    screen = pygame.display.set_mode((screenwidth, screenheight), screentype)
    # Update window caption to include the size of the window
    pygame.display.set_caption(f"Party Games ({screenwidth}x{screenheight})")
    
    # Rescale the background to the new screen resolution
    backgroundimgcopy = pygame.transform.scale(backgroundimg, (screenwidth, screenheight))
    # Rescale other images
    rescaleimages()
    # Rescale and reposition all buttons
    rescalebuttons()

# Create a function to rescale images accordingly based on dimensions of screen
def rescaleimages():

    # Declare global variables
    global chessimage, checkersimage, flappybirdimage
    
    # Adjust chess image
    # Calculates how much images need to be scaled
    scaleX = screenwidth / basewidth
    scaleY = screenheight / baseheight 
    # Gets the size of the original image and stores it in width and height variables
    originalwidth, originalheight = originalchessimg.get_size()
    # Converts to integer and calculates updated dimensions
    updatedwidth = int(originalwidth * scaleX)
    updatedheight = int(originalheight * scaleY)
    # Update the image
    chessimage = pygame.transform.smoothscale(originalchessimg, (updatedwidth, updatedheight))

    # Adjust checkers image
    # Calculates how much images need to be scaled
    scaleX = screenwidth / basewidth
    scaleY = screenheight / baseheight
    # Gets the size of the original image and stores it in width and height variables
    originalwidth, originalheight = originalcheckersimg.get_size()
    # Converts to integer and calculates updated dimensions
    updatedwidth = int(originalwidth * scaleX)
    updatedheight = int(originalheight * scaleY)
    # Update the image
    checkersimage = pygame.transform.smoothscale(originalcheckersimg, (updatedwidth, updatedheight))
    
    # Adjust flappy bird image
    # Calculates how much images need to be scaled
    scaleX = screenwidth / basewidth
    scaleY = screenheight / baseheight
    # Gets the size of the original image and stores it in width and height variables
    originalwidth, originalheight = originalflappybirdimg.get_size()
    # Converts to integer and calculates updated dimensions
    updatedwidth = int(originalwidth * scaleX)
    updatedheight = int(originalheight * scaleY)
    # Update the image
    flappybirdimage = pygame.transform.smoothscale(originalflappybirdimg, (updatedwidth, updatedheight))

# Create a function to rescale and reposition buttons accordingly based on the dimensions of screen
def rescalebuttons():
 
    # Calculates how much buttons need to be scaled
    scaleX = screenwidth / basewidth
    scaleY = screenheight / baseheight
    
    # Create a for loop to loop through all buttons in the allbuttons list
    for button in allbuttons:
        # Unpacks the Tuple to retrieve dimensions of the button
        buttonbasewidth, buttonbaseheight = basebuttonsize[id(button)]
        # Scale the buttons and store new dimensions
        newwidth = int(buttonbasewidth * scaleX)
        newheight = int(buttonbaseheight * scaleY)
        # Update button sizes
        button.size = (newwidth, newheight)
    
    # Recenter buttons by setting center position on specific point on screen based on screen dimensions and Y-scale factor
    playbutton.center = (screenwidth // 2, int(250 * scaleY))
    optionsbutton.center = (screenwidth // 2, int(320 * scaleY))
    creditsbutton.center = (screenwidth // 2, int(390 * scaleY))
    chessbutton.center = (screenwidth // 2, int(250 * scaleY))
    checkersbutton.center = (screenwidth // 2, int(320 * scaleY))
    flappybirdbutton.center = (screenwidth // 2, int(390 * scaleY))
    backbutton.center = (screenwidth // 2, int(500 * scaleY))
    resolutionbutton.center = (screenwidth // 2, int(390 * scaleY))
    chessSPbutton.center = (screenwidth // 2, int(250 * scaleY))
    chessMPbutton.center = (screenwidth // 2, int(320 * scaleY))
    fullscreenbutton.center = (screenwidth // 2, int(250 * scaleY))
    mutebutton.center = (screenwidth // 2, int(320 * scaleY))

# Create a function to toggle fullscreen mode and windowed mode
def togglefullscreen():

    # Declare variables
    global fullscreenenabled, screentype
    # Flips the variable, so if it's originally false, it changes to true and vice versa
    fullscreenenabled = not fullscreenenabled 
    
    # Check if fullscreenenabled is true (screen is not fullscreen)
    if fullscreenenabled is True:
        # Set the screentype to fullscreen
        screentype = pygame.FULLSCREEN
        # Get the resolution of the screen by system resolution
        w, h = displayresolution
        # Set the resolution of the screen to system resolution
        setresolution(w, h)
    # If fullscreenenabled is false (screen is fullscreen)
    elif fullscreenenabled is False:
        # Set the screentype to windowed
        screentype = 0
        # Keep current resolution values
        setresolution(screenwidth, screenheight)

# Create a function to toggle mute
def togglemute():
    
    # Declare variables
    global soundmuted
    # Flips the variable, so if it's originally false, it changes to true and vice versa
    soundmuted = not soundmuted
    
    # Check if soundmuted is true (music is not muted)
    if soundmuted is True:
        # Mute all volume from program
        pygame.mixer.music.set_volume(0.0)
    # If soundmuted is false (music is muted)
    elif soundmuted is False:
        # Set all program volume to full
        pygame.mixer.music.set_volume(1.0)

# Create a function to draw background
def drawbackground():
    
    # Draw the scaled background on top of surface and place it top left
    screen.blit(backgroundimgcopy, (0, 0)) 

# Load and store the chess image scaled to 50x50
originalchessimg = pygame.image.load("PartyGames/chess.png").convert_alpha()
originalchessimg = pygame.transform.scale(originalchessimg, (50, 50))
chessimage = originalchessimg.copy()

# Load and store the checkers image scaled to 50x50
originalcheckersimg = pygame.image.load("PartyGames/checkers.png").convert_alpha()
originalcheckersimg = pygame.transform.scale(originalcheckersimg, (50, 50))
checkersimage = originalcheckersimg.copy()

# Load and store the flappy bird image scaled to 50x50
originalflappybirdimg = pygame.image.load("PartyGames/birdbutton.png").convert_alpha()
originalflappybirdimg = pygame.transform.scale(originalflappybirdimg, (50, 50))
flappybirdimage = originalflappybirdimg.copy()

# Create a global list to store all active particle objects
particles = []

# Create a particle that floats upward and slowly fades and shrinks until it disappears
class FloatParticle:

    # Create a function that initializes the particles
    def __init__(object, x, y):
        # Horizontal and vertical position
        object.x = x
        object.y = y
        # Set a random initial radius between 4 to 8
        object.radius = random.randint(4, 8)
        # Set colour to white
        object.color = (255, 255, 255) 
        # Set horizontal and vertical velocity to a small drift
        object.vx = random.uniform(-0.5, 0.5) 
        object.vy = random.uniform(-1.0, -0.5)
        # Set to fully opaque 
        object.alpha = 255

    # Create function to update position, opacity, and radius of particles
    def update(self):
        
        # Create the movement by updating values horizontally and vertically 
        self.x += self.vx
        self.y += self.vy
        # Decrease the opacity
        self.alpha -= 2
        # Check if alpha values remain above or equal to 0
        if self.alpha < 0:
            self.alpha = 0
        # Decrease the radius
        self.radius -= 0.02
        # Check if radius remains above or equal to 0
        if self.radius < 0:
            self.radius = 0

    # Create a function to draw the particle onto a surface
    def draw(self, surface):
        # If the alpha or radius values are below or equal to 0, don't draw the particle
        if self.alpha <= 0 or self.radius <= 0:
            return
        
        # Create a temporary surface to draw on that has per-pixel alpha transparency enabled which allows each pixel to have different opacity
        tempsurface = pygame.Surface((self.radius * 2, self.radius * 2), pygame.SRCALPHA)
        
        # Draw particles on blank surface
        pygame.draw.circle(
            # Each colour option represents a different intensity (red, green, blue). The alpha option defines the alpha value. The first two radius values define the position (center). The final radius value is the true radius of the circle.
            tempsurface, (self.color[0], self.color[1], self.color[2], int(self.alpha)), (int(self.radius), int(self.radius)), int(self.radius)
        )
        
        # Draw the tempsurface which contains the particles and ensure the top left corner is drawn on the base surface
        surface.blit(tempsurface, (self.x - self.radius, self.y - self.radius))

# Create a function that spawns floating particles (default 3)
def spawnfloatingparticles(num=3):

    # Create a loop that loops num amount of times which creates num amount of particles
    for _ in range(num):
        # Assign a random x position on the screen
        x = random.uniform(0, screenwidth)
        # Assign a random y position on the screen near the buttom
        y = random.uniform(screenheight - 50, screenheight)
        # Add the particle details to the list we made before
        particles.append(FloatParticle(x, y))

# Create spark particle for button click
class SparkParticle:
    
    # Create a function that initializes particles with yellow colour and no speed
    def __init__(self, x, y, speed=None, color=(255, 255, 100)):
        # Horizontal and vertical position
        self.x = x
        self.y = y
        
        # Set random starting radius from 3 to 6
        self.radius = random.randint(3, 6)
        
        # Check if speed is none and give it random speed
        if speed is None:
            speed = random.uniform(0.5, 1.5)
        # Give it random direction between 0 and 360 degrees
        angledegree = random.uniform(0, 360)
        # Convert the angles to radians
        angleradians = math.radians(angledegree)
        
        # Calculate the horizontal and vertical velocity based on the speed and angle (sine of angle in radians determines vertical component of motion and cosine of angle in radians determine horizontal component of motion)
        self.vx = speed * math.cos(angleradians)
        self.vy = speed * math.sin(angleradians)
        
        # Set the colour equal to yellow
        self.color = color
        # Set the opacity to fully opaque
        self.alpha = 255

    # Create a function that updates the movement, opacity, and size
    def update(self):
        # Update vertical and horizontal component based on velocity
        self.x += self.vx
        self.y += self.vy
        # Update alpha values to fade out 
        self.alpha -= 6
        # Ensure alpha values remain 0 or above
        if self.alpha < 0:
            self.alpha = 0
        # Update radius value to shrink
        self.radius -= 0.15
        # Ensure radius values remain 0 or above
        if self.radius < 0:
            self.radius = 0

    # Draw the spark effect
    def draw(self, surface):

        # Check if alpha or radius values are equal or below 0 and don't draw if so
        if self.alpha <= 0 or self.radius <= 0:
            return
        
        # Create a temporary surface for the spark to be drawed on with per-pixel alpha transparency enabled which allows each pixel to have different opacity
        tempsurfacespark = pygame.Surface((self.radius * 2, self.radius * 2), pygame.SRCALPHA)
        
        # Draw spark effect on blank temporary surface
        pygame.draw.circle(
            # Set colour to yellow by unpacking the colour into three parts (rgb), with alpha values, first two radius center the circle, and the last one is the size of the spark
            tempsurfacespark, (*self.color, int(self.alpha)), (int(self.radius), int(self.radius)), int(self.radius)
        )
        # Draw the tempsurfacespark which contains the particles and ensure the top left corner is drawn on the base surface
        surface.blit(tempsurfacespark, (self.x - self.radius, self.y - self.radius))

# Create a function that spawns 3 particles when a button is hovered within a rectangular area
def spawnhoverparticles(rect, num=3):

    # Create a for loop that loops num times
    for _ in range(num):
        # Set a random value for x and y in the rectangular area
        x = random.uniform(rect.left, rect.right)
        y = random.uniform(rect.top, rect.bottom)
        # Add the detail of a new instance of SparkParticle class to the particles list
        particles.append(SparkParticle(x, y))

# Create a function that spawns 40 particles when a button is clicked within a rectangular area
def spawnclickparticles(rect, num=40):
    
    # Create a flor loop that loops num times
    for _ in range(num):
        # Set a random value for x and y in the rectangular area
        x = random.uniform(rect.left, rect.right)
        y = random.uniform(rect.top, rect.bottom)
        
        # Set a higher velocity within 2 and 4
        highspeed = random.uniform(2.0, 4.0) 
        
        # Set a random bright colour
        color = (
            random.randint(150,255), random.randint(150,255), random.randint(150,255)
        ) 
        # Add the detail of a new instance of SparkParticle class to the particles list with higher speed and bright colour
        particles.append(SparkParticle(x, y, speed=highspeed, color=color))

# Create a function that updates all particles and occassionally spawns FloatParticles which also removes particles that have fully shrunk or faded
def updateparticles():

    # If statement that creates a 10% chance for particles to spawn at the bottom
    if random.random() < 0.1:
        # Spawn 2 particles
        spawnfloatingparticles(num=2)
    
    # Create a for loop that updates every particle's position and state
    for p in particles:
        p.update()
    
    # Filter the particles list to ensure that only particles that are visible are kept
    particles[:] = [p for p in particles if p.alpha > 0 and p.radius > 0]

# Create a function that draws every particle onto a surface
def drawparticles(surface):

    # Create a for loop that draws every particle onto a surface
    for p in particles:
        p.draw(surface)

# Create a list that stores the objects which animate and fade to create a ghost effect on buttons once clicked
buttonclones = []

# Create a ghost effect for buttons when clicked
class ButtonClone:

    # Create a function that initializes the ghost effect
    def __init__(self, centerX, centerY, width, height, color):
        # Set horizontal and vertical position
        self.centerX = centerX
        self.centerY = centerY
        # Set width and height
        self.width = width
        self.height = height
        # Set colour
        self.color = color
        # Set opacity to be somewhat transparent
        self.opacity = 180
        # Set growth rate to determine how fast the clone expands
        self.growthrate = 6
        # Set fade rate to determine how quick the clone fades out
        self.faderate = 5
    
    # Create a function that adjusts size and opacity of the clone
    def update(self):

        # Update size
        self.width += self.growthrate
        self.height += self.growthrate
        # decrease opacity
        self.opacity -= self.faderate
        
        # Ensure the opacity is above 0
        if self.opacity < 0:
            self.opacity = 0

    # Create a function that draws the semi-transparent rectangle centered at the button
    def draw(self, surface):
        
        # Check if opacity is below or equal to 0
        if self.opacity <= 0:
            # If below or equal to 0, don't draw
            return
        
        # Create a temporary surface to draw on that has per-pixel alpha transparency enabled which allows each pixel to have different opacity
        tempsurfaceclone = pygame.Surface((self.width, self.height), pygame.SRCALPHA)
        # Set colour to individual components
        r, g, b = self.color
        # Set rectangle colour and opacity
        rectcolour = (r, g, b, int(self.opacity))  
        # Draw a rounded rectangle on the tempsurfaceclone using rectcolour 
        pygame.draw.rect(tempsurfaceclone, rectcolour, (0, 0, self.width, self.height), border_radius=12)
        
        # Calculate the top left horizontal coordinate of the rectangle
        topleftX = self.centerX - self.width // 2
        # Calculate the top left vertical coordinate of the rectangle
        topleftY = self.centerY - self.height // 2
        # Draw the tempsurfaceclone containng the rectangle onto the base surface at the top left position
        surface.blit(tempsurfaceclone, (topleftX, topleftY))

# Create a function that spawns the buttonclone 
def spawnbuttonclone(rect, color):

    # Unpack the center coordinates of the rectangle
    cx, cy = rect.center
    # Unpack the width and height of the rectangle
    w, h = rect.width, rect.height
    # Using the unpacked details, add the ButtonClone object into the buttonclones list
    buttonclones.append(ButtonClone(cx, cy, w, h, color))

# Create a function that updates and fade out all clones, which removes any that have fully disappeared
def updatebuttonclones():

    # Loop through and update all button clones in the buttonclones list
    for bc in buttonclones:
        bc.update()
        
    # Filter the buttonclones list to ensure that only buttons clones that are visible are kept
    buttonclones[:] = [bc for bc in buttonclones if bc.opacity > 0]

# Create a function that draws all active button clones
def drawbuttonclones(surface):

    # Loop through and draw all button clones that are visible
    for bc in buttonclones:
        bc.draw(surface)        

# Create a function that draws the text at specific center position
def drawtext(text, font, color, centerX, centerY):

    # Creates a text surface 
    textobject = font.render(text, True, color)
    # Stores details in a rect object that represents the boundaries of the text surface and positions
    textrect = textobject.get_rect(center=(centerX, centerY))
    # Draws the text surface onto the screen surface
    screen.blit(textobject, textrect)
    
# Create a function that draws a rectangle with rounded corners
def drawroundedbutton(rect, color, radius=12):
    # Draw the rectangle
    pygame.draw.rect(screen, color, rect, border_radius=radius)

# Create a function that checks if the mouse coordinates are inside the rectangle boundary
def buttonishovered(rect, mousepos):
    
    # Checks if mouse position is within the rectangle and returns True or False
    return rect.collidepoint(mousepos)

# Create a function that checks if the button is clicked inside the rectangle boundary
def buttonisclicked(rect, buttonpos, event):

    # Check if the left mouse button is clicked 
    if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
        # Check if within boundaries of rect and returns True or False
        return rect.collidepoint(buttonpos)
    # If not left mouse button click, automatically return False
    return False

# Create Rect objects for each button, giving them initial size and position
# Main Menu Buttons
playbutton = pygame.Rect(0, 0, 220, 60)  
optionsbutton = pygame.Rect(0, 0, 220, 60)  
creditsbutton = pygame.Rect(0, 0, 220, 60)  

# Create Play Buttons
chessbutton = pygame.Rect(0, 0, 220, 60)  
checkersbutton = pygame.Rect(0, 0, 220, 60)  
flappybirdbutton = pygame.Rect(0, 0, 220, 60)  

# Create Options / Back Button
backbutton = pygame.Rect(0, 0, 220, 60)  
resolutionbutton = pygame.Rect(0, 0, 300, 60)  
fullscreenbutton = pygame.Rect(0, 0, 300, 60)  
mutebutton = pygame.Rect(0, 0, 300, 60)

# Create Chess Buttons
chessSPbutton = pygame.Rect(0, 0, 220, 60)  
chessMPbutton = pygame.Rect(0, 0, 220, 60)

# Position the main menu buttons
playbutton.center = (screenwidth // 2, 250)
optionsbutton.center = (screenwidth // 2, 320)
creditsbutton.center = (screenwidth // 2, 390)

# Position Play Menu Buttons
chessbutton.center = (screenwidth // 2, 250)
checkersbutton.center = (screenwidth // 2, 320)
flappybirdbutton.center = (screenwidth // 2, 390)

# Position Back/Options BUttons
backbutton.center = (screenwidth // 2, 500)
resolutionbutton.center = (screenwidth // 2, 390)
fullscreenbutton.center = (screenwidth // 2, 250)
mutebutton.center = (screenwidth // 2, 320)

# Position Chess Menu Buttons
chessSPbutton.center = (screenwidth // 2, 250)
chessMPbutton.center = (screenwidth // 2, 320)

# Create dictionaries to store scaling info for buttons
buttonscale = {} 
basebuttonsize = {} 

# Create a list of all buttons for easy use and access
allbuttons = [
    playbutton, optionsbutton, creditsbutton, chessbutton, checkersbutton, flappybirdbutton, backbutton, resolutionbutton, fullscreenbutton, mutebutton, chessSPbutton, chessMPbutton
]

# Create a for loop that loops through all the rect objects in the buttons list
for rect in allbuttons:
    # Retrieves unique id for each rect object, default size no scaling
    buttonscale[id(rect)] = 1.0
    # Stores the base size as the value as a tuple in a dictionary 
    basebuttonsize[id(rect)] = (rect.width, rect.height)

# Set variable to determine how much button should scale on hover
hoverscale = 1.1 
# Set variable to determine how quickly the button scales up/down
scalespeed = 0.02 

# Create a function to draw buttons with scaling, hover, and highlight effects
def drawbutton(rect, text, mousepos):

    # Store the unique ID for each rect
    rectid = id(rect)
    # Check if the mouse is hovered over the button
    hoveractive = buttonishovered(rect, mousepos)

    # Check if a buttonID is equal to the highlightedbuttonID 
    if rectid == highlightbuttonid:
        # Set colour to select colour 
        basecolour = selectcolour
    # If not equal
    else:
        # Set colour to button colour
        basecolour = buttoncolour

    # Check if the position of cursor is over a button
    if hoveractive is True:
        # Adjust the scale of the button to grow toward hoverscale
        buttonscale[rectid] = min(buttonscale[rectid] + scalespeed, hoverscale)
    # If the position is not over a button
    elif hoveractive is False:
        # Adjust the scale of the button to decrease back to 1.0
        buttonscale[rectid] = max(buttonscale[rectid] - scalespeed, 1.0)

    # Calculate new dimensions
    scale = buttonscale[rectid]
    finalW = int(rect.width * scale)
    finalH = int(rect.height * scale)

    # Create a new rect with the scaled dimensions
    temprect = pygame.Rect(0, 0, finalW, finalH)
    # Keep the same center position
    temprect.center = rect.center

    # Default color is basecolour, but if it's hovered, use the hover colour
    color = basecolour
    
    # Check if hoveractive is true but rectID does not equal highlightbuttonID
    # This if statement ensures that only buttons that are not currently highlighted have hovercolour applied to
    if hoveractive is True and rectid != highlightbuttonid:
        # Set color to equal hovercolour
        color = hovercolour

    # Check if hoveractive is true but rectID does not equal highlightbuttonID
    if hoveractive is True and rectid != highlightbuttonid:
        # Spawns random hover particles with 50% chance
        if random.random() < 0.5: 
            # Spawns 2 particles
            spawnhoverparticles(temprect, num=2)

    # Draw the rounded button background
    drawroundedbutton(temprect, color, 12)

    # Retrieve base height of original button
    baseH = basebuttonsize[rectid][1]
    # Find the ratio between the base and the new
    ratio = finalH / baseH
    # Scale the font by that ratio
    scaledfontsize = int(basefont * ratio)
    # Ensure that the smallest doesn't go below 12 font size
    scaledfontsize = max(12, scaledfontsize)  
    # Set font to arial and updated font size
    font = pygame.font.SysFont("arial", scaledfontsize)

    # Draw the text in the center of the scaled button
    drawtext(text, font, textcolour, temprect.centerx, temprect.centery)

# Create a function that draws a button that includes the accompanying image icon and text
def drawimagebutton(rect, text, image, mousepos):

    # Store the unique ID for each rect
    rectid = id(rect)
    # Check if mouse is hovered over button
    hoveractive = buttonishovered(rect, mousepos)

    # Check if a buttonID is equal to the highlightedbuttonID 
    if rectid == highlightbuttonid:
        # Set base colour to equal select colour
        basecolour = selectcolour
    # If buttonID does not equal highlightedbuttonID
    else:
        # Set base colour to button colour
        basecolour = buttoncolour

    # Check if mouse is hovered over button
    if hoveractive is True:
        # Scale the button the hoverscale
        buttonscale[rectid] = min(buttonscale[rectid] + scalespeed, hoverscale)
    # Check if mouse is not hovered over button 
    elif hoveractive is False:
        # Scale the button back to 1.0
        buttonscale[rectid] = max(buttonscale[rectid] - scalespeed, 1.0)

    # Calculate new dimensions
    scale = buttonscale[rectid]
    finalW = int(rect.width * scale)
    finalH = int(rect.height * scale)

    # Create a new rect with the scaled dimensions
    temprect = pygame.Rect(0, 0, finalW, finalH)
    # Keep the same center position
    temprect.center = rect.center

    # Default color is basecolour, but if it's hovered, use the hover colour
    color = basecolour
    
    # Check if hoveractive is true but rectID does not equal highlightbuttonID
    # This if statement ensures that only buttons that are not currently highlighted have hovercolour applied to
    if hoveractive is True and rectid != highlightbuttonid:
        # Set color to equal hovercolour
        color = hovercolour

    # Check if hoveractive is true but rectID does not equal highlightbuttonID
    if hoveractive is True and rectid != highlightbuttonid:
        # Spawns random hover particles with 50% chance
        if random.random() < 0.5: 
            # Spawns 2 particles
            spawnhoverparticles(temprect, num=2)

    # Draw the button shape
    drawroundedbutton(temprect, color, 12)

    # Calculate image position
    imagerect = image.get_rect()
    # Adds padding on the left
    imagerect.left = temprect.left + 10
    # Vertically center the image
    imagerect.centery = temprect.centery

    # Retrieve base height of original button
    baseH = basebuttonsize[rectid][1]
    # Find the ratio between the base and the new
    ratio = finalH / baseH
    # Scale the font by that ratio
    scaledfontsize = int(basefont * ratio)
    # Ensure that the smallest doesn't go below 12 font size
    scaledfontsize = max(12, scaledfontsize)  
    # Set font to arial and updated font size
    font = pygame.font.SysFont("arial", scaledfontsize)

    # Calculate the text position to the right of the image
    textX = imagerect.right + 10 + (temprect.right - imagerect.right - 10)//2
    textY = temprect.centery

    # Draw the image and the text
    screen.blit(image, imagerect)
    drawtext(text, font, textcolour, textX, textY)

# Drawing screens
# Create a function to draw the main menu screen
def drawmainmenu(mousepos):
    # Draw background
    drawbackground()
    # Draw particles
    drawparticles(screen)
    # Draw buttonclones
    drawbuttonclones(screen)
    
    # Draw play, options, and credits buttons
    drawbutton(playbutton, "Play", mousepos)
    drawbutton(optionsbutton, "Options", mousepos)
    drawbutton(creditsbutton, "Credits", mousepos)

# Create a function to draw the intro screen
def drawintroscreen(mousepos):
    # Draw background
    drawbackground()
    # Draw particles
    drawparticles(screen)
    # Draw button clones
    drawbuttonclones(screen)
    
    # Draw chess, checkers, and flappy bird buttons
    drawimagebutton(chessbutton, "Chess", chessimage, mousepos)
    drawimagebutton(checkersbutton, "Checkers", checkersimage, mousepos)
    drawimagebutton(flappybirdbutton, "Flybird", flappybirdimage, mousepos)

    # Draw the back button
    drawbutton(backbutton, "Back", mousepos)

# Create a function to draw the chess screen
def drawchessscreen(mousepos):
    # Draw background
    drawbackground()
    # Draw particles
    drawparticles(screen)
    # Draw button clones
    drawbuttonclones(screen)

    # Draw singleplayer and multiplayer buttons
    drawbutton(chessSPbutton, "SinglePlayer", mousepos)
    drawbutton(chessMPbutton, "Multiplayer", mousepos)

    # Draw the back button
    drawbutton(backbutton, "Back", mousepos)

# Create a function to draw the checkers screen
def drawcheckersscreen(mousepos):
    # Draw background
    drawbackground()
    # Draw particles
    drawparticles(screen)
    # Draw button clones
    drawbuttonclones(screen)
    
    # Draw temp checkers text in-case no game loads
    drawtext("Checkers Screen", pygame.font.SysFont("arial", 40), textcolour, screenwidth//2, screenheight//2)
    
    # Draw back button
    drawbutton(backbutton, "Back", mousepos)

# Create a function to draw flappy bird screen
def drawflappybirdscreen(mousepos):
    # Draw background
    drawbackground()
    # Draw particles
    drawparticles(screen)
    # Draw button clones
    drawbuttonclones(screen)
    
    # Draw temp flappybird text in-case no game loads
    drawtext("Flappy Bird Screen", pygame.font.SysFont("arial", 40), textcolour, screenwidth//2, screenheight//2)
    
    # Draw back button
    drawbutton(backbutton, "Back", mousepos)

# Create a function to draw options screen
def drawoptionsscreen(mousepos):
    # Draw background
    drawbackground()
    # Draw particles
    drawparticles(screen)
    # Draw button clones
    drawbuttonclones(screen)
    
    # Retrieve width and height of screen
    w, h = screenwidth, screenheight
    # Store resolution in variable
    restext = f"Resolution: {w}x{h}"
    # Draw the resolution button including the resolution
    drawbutton(resolutionbutton, restext, mousepos)

    # Set fullscreen text to ON or OFF
    FStext = "Fullscreen: ON" if fullscreenenabled else "Fullscreen: OFF"
    # Draw fullscreen button including the status
    drawbutton(fullscreenbutton, FStext, mousepos)

    # Set mute text to ON or OFF
    mutetext = "Mute Sound: ON" if soundmuted else "Mute Sound: OFF"
    # Draw mute button including the status
    drawbutton(mutebutton, mutetext, mousepos)

    # Draw the back button
    drawbutton(backbutton, "Back", mousepos)

# Create a function to draw the credits screen
def drawcreditscreen(mousepos):
    # Draw background
    drawbackground()
    # Draw particles
    drawparticles(screen)
    # Draw button clones
    drawbuttonclones(screen)
    # Draw text of credits
    drawtext("Credits", pygame.font.SysFont("arial", 40), textcolour, screenwidth//2, 240)
    drawtext("By: Ivan, Connor", pygame.font.SysFont("arial", 40), textcolour, screenwidth//2, 290)
    drawtext("Hersh, Logan", pygame.font.SysFont("arial", 40), textcolour, screenwidth//2, 340)
    
    # Draw back button
    drawbutton(backbutton, "Back", mousepos)

# Create a function that fades out the screen
def fadeout(duration=0.1):

    # Takes a snapshot of the current screen
    oldsurface = screen.copy()
    # Stores how many alpha steps to take for fade
    fadesteps = int(255 * duration)
    
    # Loop from alpha=0 to alpha=255 in small increments
    for alpha in range(0, 256, max(1, 255 // fadesteps)):
        
        # Calls to update particles and button clones
        updateparticles()
        updatebuttonclones()
        
        # Draw the old screen
        screen.blit(oldsurface, (0, 0))
        
        # Create an overlay surface to darken the screen
        overlay = pygame.Surface((screenwidth, screenheight))
        # Fill overlay black
        overlay.fill((0, 0, 0))  
        # Set the alpha
        overlay.set_alpha(alpha)
        # Update to surface
        screen.blit(overlay, (0, 0))
        
        # Update the entire screen
        pygame.display.flip()
        # Set framerate to 60 FPS
        framerate.tick(60)

# Create a function that fades in the screen
def fadein(drawfunction, mousepos, duration=0.1):

    # Stores how many alpha steps to take for fade
    fadesteps = int(255 * duration)
    
    # Loop from alpha=255 down to alpha=0
    for alpha in range(255, -1, -max(1, 255 // fadesteps)):
        
        # Calls to update particles and button clones
        updateparticles()
        updatebuttonclones()
        
        # Draw the new screen state
        drawfunction(mousepos)
        
        # Create a black overlay that we gradually remove
        overlay = pygame.Surface((screenwidth, screenheight))
        # Fill overlay to black
        overlay.fill((0, 0, 0))
        # Set the alpha
        overlay.set_alpha(alpha)
        # Update to surface
        screen.blit(overlay, (0, 0))
        
        # Update the entire screen
        pygame.display.flip()
        # Set framerate to 60 FPS
        framerate.tick(60)

# Create a function to handle the entire animation
def transitiontoscreen(newscreen, mousepos, duration=0.1):

    # Declare variable
    global currentscreen
    # Fade the old screen
    fadeout(duration)
    # Switch to new screen
    currentscreen = newscreen
    
    # Fade in using the appropriate draw function based on the new screen
    if currentscreen == mainmenuscreen:
        fadein(drawmainmenu, mousepos, duration)
    elif currentscreen == playscreen:
        fadein(drawintroscreen, mousepos, duration)
    elif currentscreen == chessscreen:
        fadein(drawchessscreen, mousepos, duration)
    elif currentscreen == checkersscreen:
        fadein(drawcheckersscreen, mousepos, duration)
    elif currentscreen == optionsscreen:
        fadein(drawoptionsscreen, mousepos, duration)
    elif currentscreen == creditsscreen:
        fadein(drawcreditscreen, mousepos, duration)
    elif currentscreen == flappybirdscreen:
        fadein(drawflappybirdscreen, mousepos, duration)

# Create a function to pause the screen before fading so the spark effect is noticable
def pausetoviewspark(drawfunction, mousepos, duration=0.3):

    # Stores and calculates total number of frames 
    frames = int(duration * 60)  
    # Create a for loop to loop through all the frames
    for _ in range(frames):
        # Call to update the particles and button clones
        updateparticles()
        updatebuttonclones()
        # Draws new state
        drawfunction(mousepos)
        # Update entire screen
        pygame.display.flip()
        # Set framerate to 60 FPS
        framerate.tick(60)

# Main program loop
# Create a variable to determine if game is running
running = True

# While the variable running is equal to True
while running is True:
    
    # Get current mouse position
    mousepos = pygame.mouse.get_pos()
    
    # Process all queued events from Pygame's event queue (userinput, systemevents etc)
    for event in pygame.event.get():
        # Check if user closes game
        if event.type == pygame.QUIT:
            # Stop game
            running = False

        # Check for left mouse click
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            # Depending on the current screen, check which button was clicked
            if currentscreen == mainmenuscreen:
                # Check if Play button is clicked
                if buttonisclicked(playbutton, mousepos, event):
                    # Spawn particle effect, button clone, and set highlightbutton ID to equal the playbutton ID
                    spawnclickparticles(playbutton, 40)
                    spawnbuttonclone(playbutton, selectcolour)
                    highlightbuttonid = id(playbutton)
                    
                    # Adds a pause 
                    pausetoviewspark(drawmainmenu, mousepos, 0.4)
                    pausetoviewspark(drawmainmenu, mousepos, 0.5)
                    
                    # Reset the highlightbutton ID, and enable transition
                    highlightbuttonid = None
                    transitiontoscreen(playscreen, mousepos)

                # Check if Options button is clicked
                elif buttonisclicked(optionsbutton, mousepos, event):
                    # Spawn particle effect, button clone, and set highlightbutton ID to equal the optionsbutton ID
                    spawnclickparticles(optionsbutton, 40)
                    spawnbuttonclone(optionsbutton, selectcolour)
                    highlightbuttonid = id(optionsbutton)
                    
                    # Adds a pause
                    pausetoviewspark(drawmainmenu, mousepos, 0.4)
                    pausetoviewspark(drawmainmenu, mousepos, 0.5)
                    
                    # Reset the highlightbutton ID, and enable transition
                    highlightbuttonid = None
                    transitiontoscreen(optionsscreen, mousepos)

                # Check if Credits button is clicked
                elif buttonisclicked(creditsbutton, mousepos, event):
                    # Spawn particle effect, button clone, and set highlightbutton ID to equal the creditsbutton ID
                    spawnclickparticles(creditsbutton, 40)
                    spawnbuttonclone(creditsbutton, selectcolour)
                    highlightbuttonid = id(creditsbutton)
                    
                    # Adds a pause
                    pausetoviewspark(drawmainmenu, mousepos, 0.4)
                    pausetoviewspark(drawmainmenu, mousepos, 0.5)
                    
                    # Reset the highlightbutton ID, and enable transition
                    highlightbuttonid = None
                    transitiontoscreen(creditsscreen, mousepos)
            # Check if current screen is play screen
            elif currentscreen == playscreen:
                # Check if chess button is clicked
                if buttonisclicked(chessbutton, mousepos, event):
                    # Spawn particle effect, button clone, and set highlightbutton ID to equal the chessbutton ID
                    spawnclickparticles(chessbutton, 40)
                    spawnbuttonclone(chessbutton, selectcolour)
                    highlightbuttonid = id(chessbutton)
                    
                    # Adds a pause
                    pausetoviewspark(drawintroscreen, mousepos, 0.4)
                    pausetoviewspark(drawintroscreen, mousepos, 0.5)
                    
                    # Reset the highlightbutton ID, and enable transition
                    highlightbuttonid = None
                    transitiontoscreen(chessscreen, mousepos)

                # Check if checkers button is clicked
                elif buttonisclicked(checkersbutton, mousepos, event):
                    # Spawn particle effect, button clone, and set highlightbutton ID to equal the checkersbutton ID
                    spawnclickparticles(checkersbutton, 40)
                    spawnbuttonclone(checkersbutton, selectcolour)
                    highlightbuttonid = id(checkersbutton)
                    
                    # Adds a pause
                    pausetoviewspark(drawintroscreen, mousepos, 0.4)
                    pausetoviewspark(drawintroscreen, mousepos, 0.5)
                    
                    # Reset the highlightbutton ID, and enable transition
                    highlightbuttonid = None
                    
                    WIN = pygame.display.set_mode((WIDTH, HEIGHT))
                    pygame.display.set_caption('Checkers')

                    checkersgame()

                # Check if flappy bird button is clicked
                elif buttonisclicked(flappybirdbutton, mousepos, event):
                    # Spawn particle effect, button clone, and set highlightbutton ID to equal the flappybirdbutton ID
                    spawnclickparticles(flappybirdbutton, 40)
                    spawnbuttonclone(flappybirdbutton, selectcolour)
                    highlightbuttonid = id(flappybirdbutton)
                    
                    # Adds a pause
                    pausetoviewspark(drawintroscreen, mousepos, 0.4)
                    pausetoviewspark(drawintroscreen, mousepos, 0.5)
                    
                    # Reset the highlightbutton ID, and enable transition
                    highlightbuttonid = None
                    
                    import flappybird

                # Check if back button is clicked
                elif buttonisclicked(backbutton, mousepos, event):
                    # Spawn particle effect, button clone, and set highlightbutton ID to equal the backbutton ID
                    spawnclickparticles(backbutton, 40)
                    spawnbuttonclone(backbutton, selectcolour)
                    highlightbuttonid = id(backbutton)
                    
                    # Adds a pause
                    pausetoviewspark(drawintroscreen, mousepos, 0.4)
                    pausetoviewspark(drawintroscreen, mousepos, 0.5)
                    
                    # Reset the highlightbutton ID, and enable transition
                    highlightbuttonid = None
                    transitiontoscreen(mainmenuscreen, mousepos)

            # Check if current screen is equal chess screen
            elif currentscreen == chessscreen:
                # Check if back button is clicked
                if buttonisclicked(backbutton, mousepos, event):
                    # Spawn particle effect, button clone, and set highlightbutton ID to equal the backbutton ID
                    spawnclickparticles(backbutton, 40)
                    spawnbuttonclone(backbutton, selectcolour)
                    highlightbuttonid = id(backbutton)
                    
                    # Adds a pause
                    pausetoviewspark(drawchessscreen, mousepos, 0.4)
                    pausetoviewspark(drawchessscreen, mousepos, 0.5)
                    
                    # Reset the highlightbutton ID, and enable transition
                    highlightbuttonid = None
                    transitiontoscreen(mainmenuscreen, mousepos)

                # Check if singleplayer button is clicked
                elif buttonisclicked(chessSPbutton, mousepos, event):
                    # Spawn particle effect, button clone, and set highlightbutton ID to equal the singeplayerbutton ID
                    spawnclickparticles(chessSPbutton, 40)
                    spawnbuttonclone(chessSPbutton, selectcolour)
                    highlightbuttonid = id(chessSPbutton)
                    
                    # Adds a pause
                    pausetoviewspark(drawchessscreen, mousepos, 0.4)
                    pausetoviewspark(drawchessscreen, mousepos, 0.5)
                    
                    # Reset the highlightbutton ID, and enable transition
                    highlightbuttonid = None
                    
                    # Set variables to True or False to determine singleplayer or multiplayer
                    # Write-Overwrites
                    data = open("PartyGames/data", "w") 
                    # Write playerOne == "False"
                    data.write("True \n")
                    # Write playerTwo == "True"
                    data.write("False")
                    # Close data read
                    data.close()
                    # Call chess game from ChessMain.py
                    main()

                # Check if multiplayer button is clicked
                elif buttonisclicked(chessMPbutton, mousepos, event):
                    # Spawn particle effect, button clone, and set highlightbutton ID to equal the multiplayerbutton ID
                    spawnclickparticles(chessMPbutton, 40)
                    spawnbuttonclone(chessMPbutton, selectcolour)
                    highlightbuttonid = id(chessMPbutton)
                    
                    # Adds a pause
                    pausetoviewspark(drawchessscreen, mousepos, 0.4)
                    pausetoviewspark(drawchessscreen, mousepos, 0.5)
                    
                    # Reset the highlightbutton ID, and enable transition
                    highlightbuttonid = None
                    
                    # Switch to chess multiplayer mode
                    # Write-Overwrites
                    data = open("PartyGames/data", "w") 
                    # Write playerOne == "True"
                    data.write("False \n")
                    # Write playerTwo == "True"
                    data.write("True")
                    # Close data read
                    data.close()
                    # Call chess game from ChessMain.py
                    main()
                    
            # Check if current screen is equal to checkers
            elif currentscreen == checkersscreen:
                # Check if back button is clicked
                if buttonisclicked(backbutton, mousepos, event):
                    # Spawn particle effect, button clone, and set highlightbutton ID to equal the backbutton ID
                    spawnclickparticles(backbutton, 40)
                    spawnbuttonclone(backbutton, selectcolour)
                    highlightbuttonid = id(backbutton)
                    
                    # Adds a pause
                    pausetoviewspark(drawcheckersscreen, mousepos, 0.4)
                    pausetoviewspark(drawcheckersscreen, mousepos, 0.5)
                    
                    # Reset the highlightbutton ID, and enable transition
                    highlightbuttonid = None
                    transitiontoscreen(mainmenuscreen, mousepos)
                    
            # Check if current screen is equal to flappy bird screen
            elif currentscreen == flappybirdscreen:
                # Check if back button is clicked
                if buttonisclicked(backbutton, mousepos, event):
                    # Spawn particle effect, button clone, and set highlightbutton ID to equal the backbutton ID
                    spawnclickparticles(backbutton, 40)
                    spawnbuttonclone(backbutton, selectcolour)
                    highlightbuttonid = id(backbutton)

                    # Adds a pause
                    pausetoviewspark(drawflappybirdscreen, mousepos, 0.4)
                    pausetoviewspark(drawflappybirdscreen, mousepos, 0.5)
                    
                    # Reset highlightbutton ID, and enable transition
                    highlightbuttonid = None
                    transitiontoscreen(mainmenuscreen, mousepos)

            # Check if current screen is equal to options
            elif currentscreen == optionsscreen:
                # Check if resolution button is clicked
                if buttonisclicked(resolutionbutton, mousepos, event):
                    # Cycle to the next resolution in the list
                    resolutionindex = (resolutionindex + 1) % len(resolutions)
                    # Store width and height from resolution
                    w, h = resolutions[resolutionindex]
                    # Set the resolution
                    setresolution(w, h)

                # Check if fullscreen button is clicked
                if buttonisclicked(fullscreenbutton, mousepos, event):
                    # Spawn particle effect, and button clone
                    spawnclickparticles(fullscreenbutton, 40)
                    spawnbuttonclone(fullscreenbutton, selectcolour)
                    # Toggle fullscreen mode
                    togglefullscreen()

                # Check if mute button is clicked
                if buttonisclicked(mutebutton, mousepos, event):
                    # Spawn particle effect, and button clone
                    spawnclickparticles(mutebutton, 40)
                    spawnbuttonclone(mutebutton, selectcolour)
                    # Toggle mute mode
                    togglemute()
                
                # Check if back button is clicked
                if buttonisclicked(backbutton, mousepos, event):
                    # Spawn particle effect, button clone, and set highlightbutton ID to equal the backbutton ID
                    spawnclickparticles(backbutton, 40)
                    spawnbuttonclone(backbutton, selectcolour)
                    highlightbuttonid = id(backbutton)
                    
                    # Adds a pause
                    pausetoviewspark(drawoptionsscreen, mousepos, 0.4)
                    pausetoviewspark(drawoptionsscreen, mousepos, 0.5)
                    
                    # Reset the highlightbutton ID, and enable transition
                    highlightbuttonid = None
                    transitiontoscreen(mainmenuscreen, mousepos)

            # Check if current screen is equal to credits screen
            elif currentscreen == creditsscreen:
                # Check if back button is clicked
                if buttonisclicked(backbutton, mousepos, event):
                    # Spawn particle effect, button clone, and set highlightbutton ID to equal the backbutton ID
                    spawnclickparticles(backbutton, 40)
                    spawnbuttonclone(backbutton, selectcolour)
                    highlightbuttonid = id(backbutton)
                    
                    # Adds a pause
                    pausetoviewspark(drawcreditscreen, mousepos, 0.4)
                    pausetoviewspark(drawcreditscreen, mousepos, 0.5)
                    
                    # Reset the highlightbutton ID, and enable transition
                    highlightbuttonid = None
                    transitiontoscreen(mainmenuscreen, mousepos)

    # Update and draw particles and button clones
    updateparticles()
    updatebuttonclones()
    # Draw the current screen based on the global currentscreen variable
    if currentscreen == mainmenuscreen:
        drawmainmenu(mousepos)
    elif currentscreen == playscreen:
        drawintroscreen(mousepos)
    elif currentscreen == chessscreen:
        drawchessscreen(mousepos)
    elif currentscreen == checkersscreen:
        drawcheckersscreen(mousepos)
    elif currentscreen == optionsscreen:
        drawoptionsscreen(mousepos)
    elif currentscreen == creditsscreen:
        drawcreditscreen(mousepos)
    elif currentscreen == flappybirdscreen:
        drawflappybirdscreen(mousepos)
    
    # Update the entire screen
    pygame.display.flip()
    # Set the framerate to 60 FPS
    framerate.tick(60)

# When loop ends, quit pygame and program
pygame.quit()
sys.exit()
